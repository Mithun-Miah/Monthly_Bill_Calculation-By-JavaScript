// pre calculation start
let btn = document.getElementById('result_checkBtn');

btn.addEventListener('click', function(){
    let presentUnit = document.getElementById('presentUnit').value;
    let previousUnit = document.getElementById('previousUnit').value;

    let minas = presentUnit - previousUnit;
    // console.log(minas);
    document.getElementById('result').innerHTML = minas;
    // document.write('result');
});
// pre calculation end
// pre unit calculation start
let btn2 = document.getElementById('perUnitPrice_Btn');

btn2.addEventListener('click', function(){
    let totalUnitTk = document.getElementById('totalUnitTk').value;
    let totalUnit = document.getElementById('totalUnit').value;

    let divided = totalUnitTk / totalUnit;
    // console.log(divided);
    document.getElementById('perUnitPrice').innerHTML = divided;
    // document.write('result');
});
// pre unit calculation end

// water motor bill calculation start
let btn3 = document.getElementById('perWaterMotorUnitPrice_Btn');

btn3.addEventListener('click', function(){
    let totalMotorWaterUnit = document.getElementById('totalMotorWaterUnit').value;
    let perMotorWaterUnitPrice = document.getElementById('perMotorWaterUnitPrice').value;
    let totalMotorWaterUsers = document.getElementById('totalMotorWaterUsers').value;

    let totalWaterMotorBill = (totalMotorWaterUnit * perMotorWaterUnitPrice) / totalMotorWaterUsers;
    // console.log(গুন এবং ভাগ);
    document.getElementById('perPersonWaterMotorBillPrice').innerHTML = totalWaterMotorBill;
    // document.write('result');
});
// water motor bill calculation end

// per person total electricity bill calculation start
let btn4 = document.getElementById('perPersonTotalElectricityBill_Btn');

btn4.addEventListener('click', function(){
    let perPersonTotalUsesUnit = document.getElementById('perPersonTotalUsesUnit').value;
    let perUsesUnitPrice = document.getElementById('perUsesUnitPrice').value;
    let perPersonTotalMotorWaterUsesTaka = document.getElementById('perPersonTotalMotorWaterUsesTaka').value;

    let multiply = parseFloat(perPersonTotalUsesUnit) * parseFloat(perUsesUnitPrice);
    let totalSum = multiply + parseFloat(perPersonTotalMotorWaterUsesTaka);

    document.getElementById('perPersonTotalElectricityBill').innerHTML = totalSum.toFixed(2);
    // console.log(গুন এবং যোগ);
});
// per person total electricity bill calculation end

// water bill calculation start
function tmaBtn(){
    let waterAmount = document.getElementById('waterAmount').value;
    let waterUsers = document.getElementById('waterUsers').value;

    let waterBill = parseFloat(waterAmount) / parseFloat(waterUsers);

   document.getElementById('waterBillTaka').value = waterBill;
   document.getElementById('resultWater').innerHTML = waterBill;
}
// water bill calculation end

// gas bill calculation start
function gasBtn(){
    let gasAmount = document.getElementById('gasAmount').value;
    let gasUsers = document.getElementById('gasUsers').value;

    let gasBill = parseFloat(gasAmount) / parseFloat(gasUsers);

    document.getElementById('gasBillTaka').value = gasBill;
    document.getElementById('resultGas').innerHTML = gasBill;
}
// gas bill calculation end

// water and gas bill calculation start
function wgBillBtn(){
    let tWaterBill = document.getElementById('tWaterBill').value;
    let tGasBill = document.getElementById('tGasBill').value;

    let wAndGBill = parseFloat(tWaterBill) + parseFloat(tGasBill);

    document.getElementById('grossTotalBill').innerHTML = wAndGBill;
}
// water and gas bill calculation end